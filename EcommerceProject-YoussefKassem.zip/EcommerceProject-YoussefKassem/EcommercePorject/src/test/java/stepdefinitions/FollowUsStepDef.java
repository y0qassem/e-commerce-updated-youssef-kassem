package stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import java.util.ArrayList;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import pages.HomePage;




public class FollowUsStepDef {

    HomePage Home = new HomePage(Hooks.driver);
    Actions keys = new Actions(Hooks.driver);
    SoftAssert urlAssertion = new SoftAssert();
    

    @Given("Scroll down to the bottom")
    public void scrollDown(){
        JavascriptExecutor executor = (JavascriptExecutor) Hooks.driver;
        executor.executeScript("window.scrollBy(0,document.body.scrollHeight)");
        Hooks.rest();
        

    }

    @When("Click on facebook icon")
    public void clickFacebook() throws InterruptedException {
        Home.facebook.click();
        Thread.sleep(3000);
        keys.sendKeys(Keys.chord(Keys.LEFT_CONTROL, Keys.TAB));
    
            ArrayList<String> Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
        	Thread.sleep(2000);
        	Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
        	Hooks.driver.switchTo().window(Tabs.get(1));

        	System.out.println(Hooks.driver.getCurrentUrl());
        	Assert.assertEquals(Hooks.driver.getCurrentUrl(),"https://www.facebook.com/nopCommerce");

        	// that's because we need to only close tab 1
        	Hooks.driver.close();

        	Hooks.driver.switchTo().window(Tabs.get(0));
        	System.out.println(Hooks.driver.getCurrentUrl());
         
    }

    
    @And("Click on twitter icon")
    public void clickTwitter() throws InterruptedException {
        Home.twitter.click();
        Thread.sleep(3000);
        keys.sendKeys(Keys.chord(Keys.LEFT_CONTROL, Keys.TAB));
        
        ArrayList<String> Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
    	Thread.sleep(2000);
    	Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
    	Hooks.driver.switchTo().window(Tabs.get(1));

    	System.out.println(Hooks.driver.getCurrentUrl());
    	Assert.assertEquals(Hooks.driver.getCurrentUrl(),"https://twitter.com/nopCommerce");

    	// that's because we need to only close tab 1
    	Hooks.driver.close();

    	Hooks.driver.switchTo().window(Tabs.get(0));
    	System.out.println(Hooks.driver.getCurrentUrl());
    }

    @And("Click on rss icon")
    public void clickRSS() throws InterruptedException {
        keys.keyDown(Keys.LEFT_CONTROL).click(Home.rss).keyUp(Keys.LEFT_CONTROL).build().perform();
        Thread.sleep(3000);
        keys.sendKeys(Keys.chord(Keys.LEFT_CONTROL, Keys.TAB));
        
        ArrayList<String> Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
    	Thread.sleep(2000);
    	Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
    	Hooks.driver.switchTo().window(Tabs.get(1));

    	System.out.println(Hooks.driver.getCurrentUrl());
    	Assert.assertEquals(Hooks.driver.getCurrentUrl(),"https://demo.nopcommerce.com/new-online-store-is-open");

    	// that's because we need to only close tab 1
    	Hooks.driver.close();

    	Hooks.driver.switchTo().window(Tabs.get(0));
    	System.out.println(Hooks.driver.getCurrentUrl());
        
        
    }

    @And("Click on youtube icon")
    public void clickYoutube() throws InterruptedException {
        Home.youtube.click();
        Thread.sleep(3000);
        keys.sendKeys(Keys.chord(Keys.LEFT_CONTROL, Keys.TAB));
        
        ArrayList<String> Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
      	Thread.sleep(2000);
      	Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
      	Hooks.driver.switchTo().window(Tabs.get(1));

      	System.out.println(Hooks.driver.getCurrentUrl());
      	Assert.assertEquals(Hooks.driver.getCurrentUrl(),"https://www.youtube.com/user/nopCommerce");

      	// that's because we need to only close tab 1
      	Hooks.driver.close();

      	Hooks.driver.switchTo().window(Tabs.get(0));
      	System.out.println(Hooks.driver.getCurrentUrl());
    }
  
}
